/*
@license

dhtmlxGantt v.4.2.1 Stardard
This software is covered by GPL license. You also can obtain Commercial or Enterprise license to use it in non-GPL project - please contact sales@dhtmlx.com. Usage without proper license is prohibited.

(c) Dinamenta, UAB.
*/
gantt.locale = {
	date: {
		month_full: ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kes&auml;kuu", "Hein&auml;kuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"],
		month_short: ["Tam", "Hel", "Maa", "Huh", "Tou", "Kes", "Hei", "Elo", "Syy", "Lok", "Mar", "Jou"],
		day_full: ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"],
		day_short: ["Su", "Ma", "Ti", "Ke", "To", "Pe", "La"]
	},
	labels: {
		dhx_cal_today_button: "Tänään",
		day_tab: "Päivä",
		week_tab: "Viikko",
		month_tab: "Kuukausi",
		new_event: "Uusi tapahtuma",
		icon_save: "Tallenna",
		icon_cancel: "Peru",
		icon_details: "Tiedot",
		icon_edit: "Muokkaa",
		icon_delete: "Poista",
		confirm_closing: "", //Your changes will be lost, are your sure ?
		confirm_deleting: "Haluatko varmasti poistaa tapahtuman?",
		section_description: "Kuvaus",
		section_time: "Aikajakso",
		section_type:"Type",
        /* grid columns */

        column_text : "Task name",
        column_start_date : "Start time",
        column_duration : "Duration",
        column_add : "",

		/* link confirmation */
		link: "Link",
		confirm_link_deleting:"will be deleted",
		link_start: " (start)",
		link_end: " (end)",

		type_task: "Task",
		type_project: "Project",
		type_milestone: "Milestone",


        minutes: "Minutes",
        hours: "Hours",
        days: "Days",
        weeks: "Week",
        months: "Months",
        years: "Years",

		/* message popup */
		message_ok: "OK",
		message_cancel: "Peru"
	}
};

