<?php

include ('codebase/connector/gantt_connector.php');

$connection_string = "host=127.0.0.1 port=5432 dbname=odoo11 user=odoo password=odoo";
$res = pg_connect($connection_string);


require_once("codebase/connector/db_postgre.php");
$gantt = new JSONGanttConnector($res, "Postgre");
$gantt->enable_log("./some.log");
$gantt->enable_order("sortorder");
$gantt->render_links("gantt_links","id","source,target,type,lag");
$gantt->render_table("gantt_tasks","id","start_date,duration,text,progress,sortorder,parent,type,priority","");
