odoo.define('ba_web_gantt.GanttModel', function (require) {
"use strict";

var AbstractModel = require('web.AbstractModel');
  
  
var GanttModel = AbstractModel.extend({
    init: function () {
        this._super.apply(this, arguments);
        this.chart = null;
    },
    get: function () {       
        return _.extend({}, this.chart, {
            fields: this.fields,         
        });
    },
    load: function (params) {   
        this.fields = params.fields;
        this.modelName = params.modelName;
        this.chart = {
            modelName: this.modelName,
            data: [],
            domain: params.domain,
            context: params.context,
            timeframe: params.timeframe,
            start_date: params.start_date,
            stop_date: params.stop_date,
        };
        return this._loadTasks();
    },
    reload: function (handle, params) {
        if ('context' in params) {
            this.chart.context = params.context;
        }
        if ('domain' in params) {
            this.chart.domain = params.domain;
        }
        if ('timeframe' in params) {
            this.chart.timeframe = params.timeframe;
        }
        return this._loadTasks();
    },
    _loadTasks: function () {
        var fields = _.map(fields, function (fields) {
            return fields.split(':')[0];
        });      
        return this._rpc({
                model: this.modelName,
                method: 'search_read',
                context: this.chart.context,
                domain: this.chart.domain,
                fields: [
                         this.chart.start_date, 
                         this.chart.stop_date,
                         'name', 
                         'progress',
                         'parent_id',
                         'color',
                         'user_id',
                        ],
            })
            .then(this._processData.bind(this));
    },
    _processData: function (raw_data) {   
        this.chart.data = [];       
        if (!raw_data) {
            return;
        };
        for (var i = 0; i < raw_data.length; i++) {
            var start = false; 
            var stop = false;
            var color = 0;
            var user_id = '';
            if(raw_data[i][this.chart.start_date]) {
                start = moment.utc(raw_data[i][this.chart.start_date]).local().format("YYYY-MM-DD HH:mm:ss");
            };
            if(raw_data[i][this.chart.stop_date]) {
                stop = moment.utc(raw_data[i][this.chart.stop_date]).local().format("YYYY-MM-DD HH:mm:ss");
            };   
            if(raw_data[i]['color']) {
                color = raw_data[i]['color'];
            }; 
            if(raw_data[i]['user_id']) {
                user_id = raw_data[i]['user_id'];
            }; 
          
            var task_data = {
                id: raw_data[i]['id'].toString(),
                name: raw_data[i]['name'],
                start: start,
                end: stop,
                color: color,
                user_id: user_id,
            };
            if (raw_data[i]['progress']) {
                task_data['progress'] = raw_data[i]['progress'];
            };
            if (raw_data[i]['parent_id']) {
                task_data['dependencies'] = raw_data[i]['parent_id'].toString().split(',')[0];
            };
            this.chart.data.push(task_data);         
        };
    },

});
  
return GanttModel;
  
});
