{
    'name': 'Gantt Test',
    'description': 'Thaiph do gantt test.',
    'author': 'Phi Hong Thai',
    'depends': ['web','project'],
    'application': False,
    'data': ['views/views.xml',],
    'qweb': [
        'static/src/xml/*.*',
    ],

}